Selenium-based web scraper in Python.

### How To Run
* ```$ cd``` into the root directory
* Install all dependencies (i.e. Selenium, csv, etc.) via ```$ pip install```
* ```$ python scrape.py```
* Output is directed to out.csv

### Additional Notes
If you are going to make many requests to the Open Baltimore API, then you'll want to grab an API key
